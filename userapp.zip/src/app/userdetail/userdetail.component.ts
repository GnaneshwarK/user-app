import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {
userList:any=[];
  constructor(private user:UserService) { }

  ngOnInit(): void {
   // this.userList.push(history.state.data)
    //  console.log(this.userList)
      this.userList= this.user.getUserList()
      console.log(this.userList)
  }
  delete(index:number){
      this.userList.splice(index, 1);
  }

}
