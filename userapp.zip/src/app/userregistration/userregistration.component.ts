import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators,FormBuilder,FormArray} from "@angular/forms";
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css']
})
export class UserregistrationComponent implements OnInit {
  userInfo:any;
  arr:any=[];
  errMsg:string="";
  showError:boolean=false;
  constructor(private fb:FormBuilder,private router: Router,private user:UserService) {
    this.userInfo=new FormGroup({
      username:new FormControl(''),
      email:new FormControl(''),
      address:new FormArray([ 
        new FormGroup({
          city: new FormControl(''),
          state: new FormControl(''),
          pin:new FormControl('')
        })
      ])
    })
   }

  ngOnInit(): void {  
  }
   getAddress(){
    //return this.userInfo.get('address') as FormArray;
    return new FormGroup({
      city: new FormControl(''),
      state: new FormControl(''),
      pin:new FormControl('')
    });
   }
   add(){
    const addresslist = this.userInfo.get('address') as FormArray;
    addresslist.push(this.getAddress());
   }

   delete(index:any){
    console.log(index)
    const removeAddress = this.userInfo.get('address') as FormArray;
    if(index!=0){
      removeAddress.removeAt(index);
    }else{
      alert("First address cannot be removed")
    }
   
   
   }  
   saveUser(){
    if(this.userInfo.value.username!="" && this.userInfo.value.email!="")
     {
      this.showError=false;
    console.log(this.userInfo.value);
    this.user.saveUserList(this.userInfo.value);
    this.router.navigate(['details']);
      }
      else if(this.userInfo.value.username==""){
        this.showError=true;
        this.errMsg="please enter username"
      }
      else if(this.userInfo.value.email==""){
        this.showError=true;
        this.errMsg="please enter email"
      }
  }

}
