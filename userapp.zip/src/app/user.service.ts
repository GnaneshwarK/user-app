import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
 userList:any=[];
  constructor() { }

  saveUserList(data:any){
    this.userList.push(data)
  }
  getUserList(){
    return this.userList;
  }
}
